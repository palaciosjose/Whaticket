<?php
// Este archivo será sobrescrito durante la instalación
$db_host = 'localhost';
$db_user = '';
$db_password = '';
$db_name = '';
?>
