<?php
// config.php

// 1) Iniciar sesión si hace falta (para mensajes temporales)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2) Datos de conexión IMAP
define('IMAP_SERVER',   'webtvd912.com');
define('IMAP_PORT',      993);
define('IMAP_USER',      'harryaldava912.1@winic.es');
define('IMAP_PASSWORD',  'Harry271350');

// 3) Definición de asuntos
define('ASUNTO_NETFLIX_CODIGO',               'Tu código de acceso temporal de Netflix');
define('ASUNTO_NETFLIX_ACTUALIZAR_HOGAR',     'Importante: Cómo actualizar tu Hogar con Netflix');
define('ASUNTO_NETFLIX_APROVE_SESION',        'Netflix: Nueva solicitud de inicio de sesión');
define('ASUNTO_NETFLIX_RESTABLECER_CONTRASENA','Completa tu solicitud de restablecimiento de contraseña');
define('ASUNTO_NETFLIX_INICIO_SESION',        'Netflix: Tu código de inicio de sesión');

define('ASUNTO_DISNEY_CODIGO',                'Tu código de acceso único para Disney+');

define('ASUNTO_UNIVERSAL_CODIGO',             'Universal+ código de activación');

define('ASUNTO_MAX_CODIGO',                   'Tu enlace para restablecer tu contraseña');

define('ASUNTO_AMAZON_CODIGO',                'amazon.com: Sign-in attempt');
define('ASUNTO_AMAZON_CODIGO2',               'amazon.com: Intento de inicio de sesión');
define('ASUNTO_AMAZON_CODIGO3',               'Ayuda con la contraseña de Amazon');

define('ASUNTO_VIX_CODIGO',                  'Cambio de contraseña');
define('ASUNTO_PARAMOUNT_CODIGO',            'Restablecimiento de la contraseña de Paramount+');

define('ASUNTO_CRUNCHYROLL_CODIGO',          'Reset Your Crunchyroll Password');
define('ASUNTO_CRUNCHYROLL_CODIGO2',         'Restablece tu contraseña de Crunchyroll');
define('ASUNTO_CRUNCHYROLL_CODIGO3',         'Reinicia tu contraseña de Crunchyroll');

// 4) Autorización de emails (opcional)
define('EMAIL_AUTH_ENABLED', false);

// 5) Array de asuntos por plataforma
$ASUNTOS_POR_PLATAFORMA = [
    'Netflix'   => [
        ASUNTO_NETFLIX_CODIGO,
        ASUNTO_NETFLIX_ACTUALIZAR_HOGAR,
        ASUNTO_NETFLIX_APROVE_SESION,
        ASUNTO_NETFLIX_RESTABLECER_CONTRASENA,
        ASUNTO_NETFLIX_INICIO_SESION,
    ],
    'Disney'    => [
        ASUNTO_DISNEY_CODIGO,
    ],
    'Universal' => [
        ASUNTO_UNIVERSAL_CODIGO,
    ],
    'Max'       => [
        ASUNTO_MAX_CODIGO,
    ],
    'Amazon'    => [
        ASUNTO_AMAZON_CODIGO,
        ASUNTO_AMAZON_CODIGO2,
        ASUNTO_AMAZON_CODIGO3,        
    ],
    'Vix' => [
        ASUNTO_VIX_CODIGO,
    ],  
    'Paramount' => [
        ASUNTO_PARAMOUNT_CODIGO,
    ],    
    'Crunchyroll' => [
        ASUNTO_CRUNCHYROLL_CODIGO,
        ASUNTO_CRUNCHYROLL_CODIGO2,  
        ASUNTO_CRUNCHYROLL_CODIGO3,        
    ],     
];

// 6) Conexión IMAP
$inbox = null;

function open_imap_connection() {
    global $inbox;
    $inbox = imap_open(
        '{' . IMAP_SERVER . ':' . IMAP_PORT . '/imap/ssl}INBOX',
        IMAP_USER,
        IMAP_PASSWORD
    ) or die("Error al conectar con IMAP: " . imap_last_error());
}

function close_imap_connection() {
    global $inbox;
    if ($inbox) {
        imap_close($inbox);
    }
}

open_imap_connection();
register_shutdown_function('close_imap_connection');
