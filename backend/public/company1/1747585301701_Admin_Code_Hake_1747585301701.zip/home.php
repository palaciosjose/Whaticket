<?php
// home.php

// 1) Incluye tu config UNA sola vez
require_once 'config/config.php'; // Aqu�� defines $ASUNTOS_POR_PLATAFORMA, IMAP_*, etc.
require_once 'config.php'; // Aqu�� defines $ASUNTOS_POR_PLATAFORMA, IMAP_*, etc.

// 2) Inicia sesi܇n si hace falta
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3) Recupera y limpia mensajes de sesi܇n
$resultado     = $_SESSION['resultado']     ?? '';
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['resultado'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Solicita tu codigo</title>
  <!-- Bootstrap CSS -->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  />
  <!-- Font Awesome -->
  <link
    rel="stylesheet"
    href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
  />
  <link rel="stylesheet" href="styles/global_design.css">
  <link rel="icon" href="/images/logo/favicon.ico" type="image/x-icon">
    <!-- Script de seguridad (opcional) -->

</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
        <i class="fas fa-home"></i> Inicio
      </a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarOpciones"
        aria-controls="navbarOpciones"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarOpciones">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?= $GLOBAL_LINK_1 ?>" target="_blank">
              <i class="fas fa-bookmark"></i> <?= $GLOBAL_LINK_1_TEXTO ?>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= $GLOBAL_LINK_2 ?>" target="_blank">
              <i class="fab fa-telegram-plane"></i> <?= $GLOBAL_LINK_2_TEXTO ?>
            </a>
          </li>
          <?php
            $whatsappLink = 'https://wa.me/' . $GLOBAL_NUMERO_WHATSAPP
                          . '?text=' . urlencode($GLOBAL_TEXTO_WHATSAPP);
          ?>
          <li class="nav-item">
            <a class="nav-link" href="<?= $whatsappLink ?>" target="_blank">
              <i class="fab fa-whatsapp"></i> Contacto
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  
<!-- Formulario responsive -->
<div class="container-fluid py-5">
  <div class="row justify-content-center">
    <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5">
      <div class="parpadeo bg-dark text-white rounded p-3 p-md-4 mb-5">
        
        <!-- Logo -->
        <img 
          src="/images/logo/logo.png" 
          alt="Logo" 
          class="logo mb-4" 
          style="max-width: 45%; height: auto;"
        />

        <!-- T��tulo -->
        <h1 class="h4 text-center mb-4">Consulta tu correo</h1>

        <form action="mail_data_extractor.php" method="POST" class="mb-0">

          <div class="mb-3">
            <label for="email" class="form-label">
              <i class="fas fa-envelope"></i> Correo a consultar
            </label>
            <input
              type="email"
              id="email"
              name="email"
              class="form-control form-control-lg bg-dark text-white"
              placeholder="correo@ejemplo.com"
              required maxlength="50"
            />
          </div>

          <div class="mb-3">
            <label for="password" class="form-label">
              <i class="fas fa-key"></i> Acceso
            </label>
            <input
              type="password"
              id="password"
              name="password"
              class="form-control form-control-lg bg-dark text-white"
              placeholder="******"
              required
            />
          </div>

          <div class="mb-4">
            <label for="platform" class="form-label">
              <i class="fas fa-list"></i> Elija plataforma
            </label>
            <select
              name="platform"
              id="platform"
              class="form-select form-select-lg bg-dark text-white"
              required
            >
              <option value="" disabled selected>Seleccione...</option>
              <?php foreach ($ASUNTOS_POR_PLATAFORMA as $plataforma => $asuntos): ?>
                <option value="<?= htmlspecialchars($plataforma, ENT_QUOTES) ?>">
                  <?= htmlspecialchars($plataforma, ENT_QUOTES) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <button
            type="submit"
            class="btn btn-danger btn-lg w-100"
          >
            <i class="fas fa-search me-2"></i> Buscar Mensajes
          </button>

        </form>
        
        <!-- Error -->
        <?php if ($error_message): ?>
          <div class="alert alert-danger text-center mt-4 mb-0">
            <i class="fas fa-exclamation-triangle me-1"></i> <?= $error_message ?>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
</div>


<!-- Modal de resultado -->
<div class="modal fade" id="resultModal" tabindex="-1" aria-labelledby="resultModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content d-flex flex-column rounded-3 shadow" style="max-height: 90vh;">
      
      <!-- Header -->
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="resultModalLabel">
          <i class="fas fa-envelope-open-text me-2"></i> Resultado de la busqueda
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      
      <!-- Body: ocupa todo el espacio restante y es scrollable -->
      <div 
        class="modal-body overflow-auto flex-grow-1 p-3 p-md-4" 
        style="background: #f9fafb;"
      >
        <?= $resultado ?>
      </div>

    </div>
  </div>
</div>


  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <?php if ($resultado): ?>
    <script>
      // Al cargar la p��gina, si hay $resultado, abrimos el modal
      const resultModal = new bootstrap.Modal(document.getElementById('resultModal'));
      resultModal.show();
    </script>
  <?php endif; ?>
  
    <!-- Footer -->
<footer class="bg-dark text-white text-center py-3" style="margin-top: 2rem;">
  <p class="mb-0">
    Quieres tu pagina web para codigos. Contactame:
    <a
      href="https://wa.me/51964027654?text=Hola%20estoy%20interesado%20en%20una%20pagina%20web%20para%20codigos%20netflix"
      class="text-white"
      target="_blank"
    >
      <i class="fab fa-whatsapp"></i> WhatsApp
    </a>
  </p>
</footer>

</body>
</html>
