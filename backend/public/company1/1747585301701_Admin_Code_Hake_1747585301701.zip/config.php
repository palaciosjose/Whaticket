<?php
define('IMAP_HOST', '{webtvd912.com:993/imap/ssl/novalidate-cert}');
define('IMAP_USERNAME', 'harryaldava912.1@winic.es');
define('IMAP_PASSWORD', 'Harry271350');

/**************************CONFIGURACIÓN EXTRA*******************************/
$GLOBAL_LINK_1_TEXTO='Sitio Web';
$GLOBAL_LINK_1='https://www.hakebotpremiumv5.winic.es/';
$GLOBAL_LINK_2_TEXTO='Telegram';
$GLOBAL_LINK_2='https://t.meTvHake/';
$GLOBAL_NUMERO_WHATSAPP='51964027654';
$GLOBAL_TEXTO_WHATSAPP='Hola, tengo una consulta sobre sus servicios.';
