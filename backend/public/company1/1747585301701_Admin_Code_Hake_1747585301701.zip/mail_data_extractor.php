<?php
// -------------------------------------------------
// mail_data_extractor.php
// -------------------------------------------------

// 1) Incluye TU ÚNICO config: aquí suponemos que tu archivo central se llama config.php
require_once __DIR__ . '/config/config.php';   // <-- Asegúrate que dentro está $ASUNTOS_POR_PLATAFORMA, IMAP_* y open_imap_connection()

// 2) Decodificación de correos
require_once __DIR__ . '/decode.php';

// 3) Conexión a BD de usuarios
require_once __DIR__ . '/admin/conexion.php';

// 4) Sesión para mensajes
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 5) Recuperar datos del formulario
$emailRaw          = $_POST['email']    ?? '';
$passwordIngresada = $_POST['password'] ?? '';
$platformRaw       = $_POST['platform'] ?? '';

// 6) Autenticación de usuario
$stmt = $pdo->prepare("SELECT * FROM usuarios_correos WHERE email = :email LIMIT 1");
$stmt->execute(['email' => $emailRaw]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (! $usuario || $passwordIngresada !== $usuario['password']) {
    $_SESSION['error_message'] = "Credenciales inválidas.";
    header('Location: home.php');
    exit;
}

// 7) Validar y escapar email
function validate_email($e) {
    if (empty($e) || !filter_var($e, FILTER_VALIDATE_EMAIL)) {
        return 'Correo inválido o vacío.';
    }
    if (strlen($e) > 50) {
        return 'El correo no debe superar 50 caracteres.';
    }
    return '';
}
if ($err = validate_email($emailRaw)) {
    $_SESSION['error_message'] = $err;
    header('Location: home.php');
    exit;
}
$email = htmlspecialchars($emailRaw, ENT_QUOTES, 'UTF-8');

// 8) Normalizar y validar plataforma (case‑insensitive)
$platform       = trim($platformRaw);
$lowerMap       = array_change_key_case($ASUNTOS_POR_PLATAFORMA, CASE_LOWER);
$platformLower  = mb_strtolower($platform, 'UTF-8');

if (isset($lowerMap[$platformLower])) {
    foreach (array_keys($ASUNTOS_POR_PLATAFORMA) as $origKey) {
        if (mb_strtolower($origKey, 'UTF-8') === $platformLower) {
            $platform = $origKey;
            break;
        }
    }
}

if (! isset($ASUNTOS_POR_PLATAFORMA[$platform])) {
    $_SESSION['error_message'] = 'Plataforma inválida: "' . htmlspecialchars($platformRaw, ENT_QUOTES) . '".';
    header('Location: home.php');
    exit;
}

// 9) Busca todos los mensajes de TODOS los asuntos de esa plataforma
open_imap_connection();
$allIds      = [];
$idToSubject = [];

foreach ($ASUNTOS_POR_PLATAFORMA[$platform] as $subject) {
    $criteria = 'TO "' . addslashes($email) . '" SUBJECT "' . addslashes($subject) . '"';
    $res = imap_search($inbox, $criteria);
    if (is_array($res)) {
        foreach ($res as $msgId) {
            $allIds[$msgId]        = $msgId;
            $idToSubject[$msgId] = $subject;
        }
    }
}
close_imap_connection();

// 10) Si no hay IDs, mostramos “0 mensajes”
if (empty($allIds)) {
    $_SESSION['resultado'] = '0 mensajes encontrados.';
    header('Location: home.php');
    exit;
}

// 11) Tomar el ID más alto (el más reciente)
$latestId      = max($allIds);
$chosenSubject = $idToSubject[$latestId];

// 12) Extraer encabezado y cuerpo
open_imap_connection();  // reabrir antes de headerinfo y fetchbody
$header  = imap_headerinfo($inbox, $latestId);
$bodyRaw = get_email_body($inbox, $latestId, $header);
close_imap_connection();

$body = process_email_body($bodyRaw);
$body = quoted_printable_decode($body);

// 13) Generar HTML de salida con scroll horizontal y vertical
$output  = "<h5 style=\"text-align:center;\">Asunto: "
         . htmlspecialchars($chosenSubject, ENT_QUOTES)
         . "</h5>\n";

// Este será ahora el único scroll
$output .= "<div style=\"
    overflow: auto;       /* scroll X & Y */
    max-height: 50vh;      /* controla altura aquí */
    background: #222;
    padding: 10px;
    border-radius: 5px;
    box-sizing: border-box;
\">\n";

$output .=     $body . "\n";
$output .= "</div>\n";




// 14) Guardar en sesión y redirigir
$_SESSION['resultado'] = $output;
header('Location: home.php');
exit;
