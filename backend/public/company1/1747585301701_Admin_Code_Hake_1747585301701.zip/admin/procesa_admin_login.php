<?php
session_start();
require_once 'conexion.php'; // tu archivo con la conexión PDO ($pdo)

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validar que existan
if (!$username || !$password) {
  $_SESSION['error_message'] = "Por favor, completa ambos campos.";
  header('Location: login_admin.php');
  exit;
}

// Buscar admin en la base
$sql = "SELECT * FROM administradores WHERE username = :user LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute(['user' => $username]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if ($admin) {
  // Verificar contraseña
  if (password_verify($password, $admin['password'])) {
    // Contraseña válida -> crear sesión
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    
    // Redirigir al panel de administración
    header('Location: dashboard.php');
    exit;
  } else {
    // Contraseña incorrecta
    $_SESSION['error_message'] = "Contraseña inválida.";
    header('Location: login_admin.php');
    exit;
  }
} else {
  // Usuario no encontrado
  $_SESSION['error_message'] = "Usuario no existe.";
  header('Location: login_admin.php');
  exit;
}
