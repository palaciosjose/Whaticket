<?php
// Ejemplo de conexión con PDO a MySQL
$DB_HOST = 'localhost';       // o la IP/host de tu servidor
$DB_NAME = 'winic_premiumcode';      // Nombre de tu base de datos
$DB_USER = 'winic_premiumcode';            // Usuario de la base
$DB_PASS = 'LGD3GIhflE0h';        // Contraseña de la base

try {
    $dsn = "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4";
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    exit("Error de conexión: " . $e->getMessage());
}
