<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

require_once 'conexion.php'; // Archivo con tu conexión PDO ($pdo)
require_once 'config.php';    // Archivo con la lista de plataformas

// Verificar el token CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error_message'] = "Token CSRF inválido.";
    header('Location: admin_asignar_masivo.php');
    exit;
}

// Recoger y sanitizar datos del formulario
$emails_input = isset($_POST['emails']) ? trim($_POST['emails']) : '';
$access_code  = isset($_POST['access_code']) ? trim($_POST['access_code']) : '';
$plataforma   = isset($_POST['plataforma']) ? trim($_POST['plataforma']) : '';

// Almacenar los correos temporalmente en la sesión en caso de error
$_SESSION['temp_emails'] = $emails_input;

// Validar campos
if (empty($emails_input) || empty($access_code) || empty($plataforma)) {
    $_SESSION['error_message'] = "Todos los campos son obligatorios.";
    header('Location: admin_asignar_masivo.php');
    exit;
}

// Validar plataforma
if (!in_array($plataforma, $plataformasDisponibles)) {
    $_SESSION['error_message'] = "Plataforma seleccionada inválida.";
    header('Location: admin_asignar_masivo.php');
    exit;
}

// Convertir los correos electrónicos en un array, eliminando espacios y líneas vacías
$emails_array = array_filter(array_map('trim', explode("\n", $emails_input)));

// Eliminar duplicados
$emails_array = array_unique($emails_array);

// Validar cada correo electrónico
$invalid_emails = [];
foreach ($emails_array as $email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $invalid_emails[] = $email;
    }
}

if (!empty($invalid_emails)) {
    $_SESSION['error_message'] = "Los siguientes correos electrónicos son inválidos:<br>" . implode('<br>', array_map('htmlspecialchars', $invalid_emails));
    header('Location: admin_asignar_masivo.php');
    exit;
}

// Preparar la consulta de inserción
$sqlInsert = "INSERT INTO usuarios_correos (email, password, plataforma, created_at)
              VALUES (:email, :password, :plataforma, NOW())";

$stmtInsert = $pdo->prepare($sqlInsert);

// Contadores para el feedback
$inserted = 0;
$duplicates = 0;
$errors = 0;

// Iniciar una transacción para asegurar la integridad de los datos
$pdo->beginTransaction();

try {
    foreach ($emails_array as $email) {
        try {
            $stmtInsert->execute([
                'email'      => $email,
                'password'   => $access_code, // Almacenar el código de acceso en texto plano
                'plataforma' => $plataforma
            ]);
            $inserted++;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Código para duplicados (violación de restricción de unicidad)
                $duplicates++;
            } else {
                $errors++;
            }
            // Continuar con el siguiente correo
            continue;
        }
    }

    // Confirmar la transacción
    $pdo->commit();

    // Preparar el mensaje de feedback
    $feedback = "";
    if ($inserted > 0) {
        $feedback .= "$inserted correo(s) asignado(s) exitosamente.<br>";
    }
    if ($duplicates > 0) {
        $feedback .= "$duplicates correo(s) ya existían y fueron omitidos.<br>";
    }
    if ($errors > 0) {
        $feedback .= "$errors error(es) ocurrieron durante la asignación.<br>";
    }

    $_SESSION['exito_message'] = $feedback;

} catch (Exception $e) {
    // Revertir la transacción en caso de error
    $pdo->rollBack();
    $_SESSION['error_message'] = "Ocurrió un error al asignar los correos: " . $e->getMessage();
    header('Location: admin_asignar_masivo.php');
    exit;
}

// Limpiar los correos temporales
unset($_SESSION['temp_emails']);

// Redirigir de vuelta al formulario con mensajes de éxito
header('Location: admin_asignar_masivo.php');
exit;
?>
