<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

require_once 'conexion.php'; // Archivo con tu conexión PDO ($pdo)
require_once 'config.php';    // Archivo con la lista de plataformas
    $_SESSION['exito_message'] = "¡Registro actualizado exitosamente!";
    
// Verificar si se proporcionó un ID válido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error_message'] = "ID inválido.";
    header('Location: admin_list_correo.php');
    exit;
}

$id = (int)$_GET['id'];

// Obtener los detalles del correo
$sql = "SELECT id, email, password, plataforma FROM usuarios_correos WHERE id = :id LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$correo = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$correo) {
    $_SESSION['error_message'] = "Registro no encontrado.";
    header('Location: admin_list_correo.php');
    exit;
}

// Generar un token CSRF único para la sesión
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Manejar mensajes de éxito o error
$exito_message = isset($_SESSION['exito_message']) ? $_SESSION['exito_message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';

unset($_SESSION['exito_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - Editar Correo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS (CDN) -->
    <link 
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    >
    <!-- Font Awesome (CDN) -->
    <link 
        rel="stylesheet"
        href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    >

    <style>
        body {
            background-color: #343a40; /* Fondo oscuro */
            color: #fff;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .card {
            background-color: rgba(0,0,0,0.7);
            border: none;
        }
        .card .card-title,
        .card label {
            color: #fff;
        }
        .form-control, .form-select {
            background-color: #212529;
            border: 1px solid #666;
            color: #fff;
        }
        .form-select option {
            color: #000;
        }
        .btn-primary {
            background-color: #e50914; /* Color tipo "Netflix" */
            border: none;
        }
        .btn-primary:hover {
            background-color: #f6121d;
        }
        .btn-danger {
            background-color: #dc3545;
            border: none;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<!-- Barra de navegación -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">

        <!-- Título / Logo del panel -->
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-user-cog"></i> Panel Admin
        </a>

        <!-- Botón para colapsar en pantallas pequeñas -->
        <button 
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarAdmin"
            aria-controls="navbarAdmin"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Contenedor colapsable -->
        <div class="collapse navbar-collapse" id="navbarAdmin">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                
                <!-- Botón: Ver Correos -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_list_correo.php">
                        <i class="fas fa-envelope"></i> Ver Correos
                    </a>
                </li>

                <!-- Botón: Asignar Contraseñas -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_asignar_contrasena.php">
                        <i class="fas fa-key"></i> Asignar Contraseñas
                    </a>
                </li>

                <!-- Botón: Asignar Masivo -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_asignar_masivo.php">
                        <i class="fas fa-users"></i> Asignar Masivo
                    </a>
                </li>

                <!-- Botón de Logout -->
                <li class="nav-item ms-2">
                    <a href="logout_admin.php" class="btn btn-danger btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                    </a>
                </li>
            </ul>
        </div>
        <!-- Fin contenedor colapsable -->
    </div>
</nav>
<!-- Fin Barra de navegación -->

<!-- Contenedor principal -->
<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="col-12 col-md-8 col-lg-6">
        <div class="card p-4 shadow">
            <div class="card-body">
                <h1 class="card-title text-center mb-4">
                    <i class="fas fa-edit"></i> Editar Correo
                </h1>

                <!-- Bloque para mostrar mensajes de éxito o error -->
                <?php if (!empty($exito_message)): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <div><?= htmlspecialchars($exito_message) ?></div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger d-flex align-items-center" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <div><?= htmlspecialchars($error_message) ?></div>
                    </div>
                <?php endif; ?>
                <!-- Fin bloque de mensajes -->

                <!-- Formulario de Edición -->
                <form action="admin_update_correo.php" method="POST" class="mt-2">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($correo['id']) ?>">

                    <!-- Campo: Email -->
                    <div class="mb-3">
                        <label for="email" class="form-label">
                            <i class="fas fa-envelope"></i> Correo
                        </label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-control"
                            value="<?= htmlspecialchars($correo['email']) ?>"
                            required
                        >
                    </div>

                    <!-- Campo: Contraseña -->
                    <div class="mb-3">
                        <label for="password" class="form-label">
                            <i class="fas fa-lock"></i> Contraseña
                        </label>
                        <input 
                            type="text" 
                            id="password" 
                            name="password" 
                            class="form-control"
                            value="<?= htmlspecialchars($correo['password']) ?>"
                            required
                        >
                    </div>

                    <!-- Campo: Plataforma (Listado Desplegable) -->
                    <div class="mb-3">
                        <label for="plataforma" class="form-label">
                            <i class="fas fa-tv"></i> Plataforma
                        </label>
                        <select 
                            id="plataforma" 
                            name="plataforma" 
                            class="form-select"
                            required
                        >
                            <option value="" disabled>Seleccione una plataforma</option>
                            <?php foreach ($plataformasDisponibles as $plat): ?>
                                <option value="<?= htmlspecialchars($plat) ?>" <?= ($correo['plataforma'] === $plat) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($plat) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Botones de Acción -->
                    <div class="d-flex justify-content-between">
                        <a href="admin_list_correo.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Guardar Cambios
                        </button>
                    </div>
                </form>
                <!-- Fin Formulario de Edición -->
            </div>
        </div>
    </div>
</div>
<!-- Fin Contenedor principal -->

<!-- Bootstrap JS (CDN) -->
<script 
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
></script>
</body>
</html>
