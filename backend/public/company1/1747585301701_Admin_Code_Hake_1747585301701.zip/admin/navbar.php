<!-- Barra de navegación -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">

        <!-- Título / Logo del panel -->
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-user-cog"></i> Panel Admin
        </a>

        <!-- Botón para colapsar en pantallas pequeñas -->
        <button 
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarAdmin"
            aria-controls="navbarAdmin"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Contenedor colapsable -->
        <div class="collapse navbar-collapse" id="navbarAdmin">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                
                <!-- Botón: Ver Correos -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_list_correo.php">
                        <i class="fas fa-envelope"></i> Ver Correos
                    </a>
                </li>

                <!-- Botón: Asignar Contraseñas -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_asignar_contrasena.php">
                        <i class="fas fa-key"></i> Asignar Contraseñas
                    </a>
                </li>

                <!-- Botón: Asignar Masivo -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_asignar_masivo.php">
                        <i class="fas fa-users"></i> Asignar Masivo
                    </a>
                </li>

                <!-- Botón de Logout -->
                <li class="nav-item ms-2">
                    <a href="logout_admin.php" class="btn btn-danger btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                    </a>
                </li>
            </ul>
        </div>
        <!-- Fin contenedor colapsable -->
    </div>
</nav>
<!-- Fin Barra de navegación -->