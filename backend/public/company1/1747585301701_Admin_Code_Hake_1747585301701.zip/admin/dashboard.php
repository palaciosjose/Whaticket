<?php
// admin/dashboard.php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Recoger mensajes (si existen)
$exito_message = $_SESSION['exito_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';

// Limpiar para no repetir mensajes
unset($_SESSION['exito_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <!-- Dashboard Styles -->
    <link rel="stylesheet" href="styles/dashboard.css">
</head>
<body>

    <!-- Barra de navegación incluida -->
    <?php include 'navbar.php'; ?>

    <div class="container dashboard-container">
        <!-- Bloque de mensajes -->
        <?php if ($exito_message): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
                <i class="fas fa-check-circle"></i>
                <div class="ms-2"><?= htmlspecialchars($exito_message) ?></div>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger d-flex align-items-center" role="alert">
                <i class="fas fa-exclamation-triangle"></i>
                <div class="ms-2"><?= htmlspecialchars($error_message) ?></div>
            </div>
        <?php endif; ?>

        <!-- Grilla de tarjetas responsive -->
        <div class="dashboard-row mt-4">
            <a href="admin_list_correo.php" class="text-decoration-none">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <i class="fas fa-envelope"></i>
                        <h5>Ver Correos</h5>
                    </div>
                </div>
            </a>
            <a href="admin_asignar_contrasena.php" class="text-decoration-none">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <i class="fas fa-key"></i>
                        <h5>Asignar Contraseñas</h5>
                    </div>
                </div>
            </a>
            <a href="admin_asignar_masivo.php" class="text-decoration-none">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <i class="fas fa-users"></i>
                        <h5>Asignar Masivo</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
