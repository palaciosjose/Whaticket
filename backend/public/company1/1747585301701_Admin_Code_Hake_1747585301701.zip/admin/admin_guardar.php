<?php
session_start();
require_once 'conexion.php'; // Asegúrate de que este archivo configure correctamente $pdo

// Recoger y sanitizar datos del formulario
$email      = isset($_POST['email']) ? trim($_POST['email']) : '';
$password   = isset($_POST['password']) ? trim($_POST['password']) : '';
$plataforma = isset($_POST['plataforma']) ? trim($_POST['plataforma']) : '';

// Validar campos
if (empty($email) || empty($password) || empty($plataforma)) {
    $_SESSION['error_message'] = "Datos incompletos (correo, contraseña o plataforma).";
    header('Location: admin_asignar_contrasena.php');
    exit;
}

// Validar formato del correo
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error_message'] = "El formato del correo es inválido.";
    header('Location: admin_asignar_contrasena.php');
    exit;
}

try {
    // Preparar la consulta de inserción
    $sqlInsert = "INSERT INTO usuarios_correos (email, password, plataforma)
                  VALUES (:email, :password, :plataforma)";
    $stmtIns = $pdo->prepare($sqlInsert);
    $stmtIns->execute([
        'email'      => $email,
        'password'   => $password, // Almacena la contraseña en texto plano (ver nota de seguridad abajo)
        'plataforma' => $plataforma
    ]);

    $_SESSION['exito_message'] = "¡Contraseña asignada para: $email en la plataforma $plataforma!";

} catch (PDOException $e) {
    // Manejar errores de inserción duplicada u otros errores de BD
    if ($e->getCode() == 23000) { // Código de error para violación de restricción de integridad
        $_SESSION['error_message'] = "El correo '$email' ya está registrado.";
    } else {
        $_SESSION['error_message'] = "Error en la BD: " . $e->getMessage();
    }
    header('Location: admin_asignar_contrasena.php');
    exit;
}

// Redirigir de vuelta al formulario con mensaje de éxito
header('Location: admin_asignar_contrasena.php');
exit;
?>
