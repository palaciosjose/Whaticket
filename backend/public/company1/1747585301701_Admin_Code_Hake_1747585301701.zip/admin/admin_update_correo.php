<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

require_once 'conexion.php'; // Archivo con tu conexión PDO ($pdo)

// Verificar el token CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error_message'] = "Token CSRF inválido.";
    header('Location: admin_list_correo.php');
    exit;
}

// Recoger y sanitizar datos del formulario
$id         = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$email      = isset($_POST['email']) ? trim($_POST['email']) : '';
$password   = isset($_POST['password']) ? trim($_POST['password']) : '';
$plataforma = isset($_POST['plataforma']) ? trim($_POST['plataforma']) : '';

// Validar campos
if ($id <= 0 || empty($email) || empty($password) || empty($plataforma)) {
    $_SESSION['error_message'] = "Datos incompletos o inválidos.";
    header("Location: admin_edit_correo.php?id=$id");
    exit;
}

// Validar formato del correo
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error_message'] = "El formato del correo es inválido.";
    header("Location: admin_edit_correo.php?id=$id");
    exit;
}

try {
    // Preparar la consulta de actualización
    $sqlUpdate = "UPDATE usuarios_correos
                  SET email = :email,
                      password = :password,
                      plataforma = :plataforma
                  WHERE id = :id";
    $stmtUp = $pdo->prepare($sqlUpdate);
    $stmtUp->execute([
        'email'      => $email,
        'password'   => $password, // Almacena la contraseña en texto plano (ver nota de seguridad abajo)
        'plataforma' => $plataforma,
        'id'         => $id
    ]);

    $_SESSION['exito_message'] = "¡Registro actualizado exitosamente!";
} catch (PDOException $e) {
    // Manejar errores, como duplicados de correo
    if ($e->getCode() == 23000) { // Código de error para violación de restricción de integridad
        $_SESSION['error_message'] = "El correo '$email' ya está registrado.";
    } else {
        $_SESSION['error_message'] = "Error en la BD: " . $e->getMessage();
    }
    header("Location: admin_edit_correo.php?id=$id");
    exit;
}

// Redirigir de vuelta a la lista de correos con mensaje de éxito
header('Location: admin_list_correo.php');
exit;
?>
