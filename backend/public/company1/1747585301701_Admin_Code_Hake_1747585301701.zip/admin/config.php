<?php
// config.php

$plataformasDisponibles = ['Netflix', 'Disney', 'Amazon', 'Universal', 'Max', 'Vix', 'Paramount', 'Crunchyroll']; // Agremás según tus necesidades
?>
