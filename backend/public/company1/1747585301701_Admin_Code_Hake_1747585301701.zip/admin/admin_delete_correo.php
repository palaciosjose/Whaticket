<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

require_once 'conexion.php'; // Archivo con tu conexión PDO ($pdo)

// Verificar el token CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error_message'] = "Token CSRF inválido.";
    header('Location: admin_list_correo.php');
    exit;
}

// Recoger y sanitizar el ID
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

// Validar el ID
if ($id <= 0) {
    $_SESSION['error_message'] = "ID inválido.";
    header('Location: admin_list_correo.php');
    exit;
}

try {
    // Preparar la consulta de eliminación
    $sqlDelete = "DELETE FROM usuarios_correos WHERE id = :id";
    $stmtDel = $pdo->prepare($sqlDelete);
    $stmtDel->execute(['id' => $id]);

    if ($stmtDel->rowCount()) {
        $_SESSION['exito_message'] = "¡Registro eliminado exitosamente!";
    } else {
        $_SESSION['error_message'] = "Registro no encontrado o ya fue eliminado.";
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error en la BD: " . $e->getMessage();
}

// Redirigir de vuelta a la lista de correos con mensaje
header('Location: admin_list_correo.php');
exit;
?>
