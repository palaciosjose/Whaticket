<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

require_once 'conexion.php'; // Archivo con tu conexión PDO ($pdo)

// Verificar el token CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error_message'] = "Token CSRF inválido.";
    header('Location: admin_list_correo.php');
    exit;
}

// Recoger y sanitizar los IDs seleccionados
$selected_ids = isset($_POST['selected_ids']) ? $_POST['selected_ids'] : [];

if (empty($selected_ids)) {
    $_SESSION['error_message'] = "No se seleccionaron registros para eliminar.";
    header('Location: admin_list_correo.php');
    exit;
}

// Filtrar y asegurar que todos los IDs sean números
$filtered_ids = array_filter($selected_ids, function($id) {
    return is_numeric($id) && $id > 0;
});

if (empty($filtered_ids)) {
    $_SESSION['error_message'] = "IDs seleccionados inválidos.";
    header('Location: admin_list_correo.php');
    exit;
}

try {
    // Preparar la consulta de eliminación
    // Crear marcadores de posición dinámicamente
    $placeholders = rtrim(str_repeat('?,', count($filtered_ids)), ',');
    $sqlDelete = "DELETE FROM usuarios_correos WHERE id IN ($placeholders)";
    $stmtDel = $pdo->prepare($sqlDelete);
    $stmtDel->execute($filtered_ids);

    $deletedCount = $stmtDel->rowCount();

    if ($deletedCount > 0) {
        $_SESSION['exito_message'] = "¡Se eliminaron $deletedCount registro(s) exitosamente!";
    } else {
        $_SESSION['error_message'] = "No se encontraron registros para eliminar.";
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error en la BD: " . $e->getMessage();
}

// Redirigir de vuelta a la lista de correos con mensaje
header('Location: admin_list_correo.php');
exit;
?>
