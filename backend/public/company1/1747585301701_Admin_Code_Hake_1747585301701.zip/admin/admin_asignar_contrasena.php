<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}
require_once 'config.php';    // Archivo con la lista de plataformas

// Recoger mensajes (si existen)
$exito_message = isset($_SESSION['exito_message']) ? $_SESSION['exito_message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';

// Limpiar para no repetir mensajes
unset($_SESSION['exito_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - Asignar Contraseña</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS (CDN) -->
    <link 
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    >
    <!-- Font Awesome (CDN) -->
    <link 
        rel="stylesheet"
        href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    >

    <style>
        body {
            background-color: #343a40; /* Fondo oscuro */
        }
        .navbar {
            margin-bottom: 20px; /* Espacio debajo de la barra de navegación */
        }
        .card {
            background-color: rgba(0,0,0,0.7); /* Tarjeta semitransparente */
            border: none;
        }
        .card .card-title,
        .card label {
            color: #fff; /* Texto blanco en el formulario */
        }
        .form-control, .form-select {
            background-color: #212529; /* Fondo de los inputs */
            border: 1px solid #666;
            color: #fff;
        }
        .btn-primary {
            background-color: #e50914; /* Color tipo "Netflix" */
            border: none;
        }
        .btn-primary:hover {
            background-color: #f6121d;
        }
    </style>
</head>
<body>

    <?php include 'navbar.php'; ?>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
  <div class="col-12 col-md-8 col-lg-6">
    <div class="card p-4 shadow">
      <div class="card-body">
        <h1 class="card-title text-center mb-4">
          <i class="fas fa-key"></i> Asignar/Actualizar Contraseña
        </h1>

        <!-- Bloque para mostrar mensajes de éxito o error -->
        <?php if (!empty($exito_message)): ?>
          <div class="alert alert-success d-flex align-items-center" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <div><?= htmlspecialchars($exito_message) ?></div>
          </div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
          <div class="alert alert-danger d-flex align-items-center" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <div><?= htmlspecialchars($error_message) ?></div>
          </div>
        <?php endif; ?>
        <!-- Fin bloque de mensajes -->

        <!-- Formulario -->
        <form action="admin_guardar.php" method="POST" class="mt-2">
          
          <!-- Campo: Email -->
          <div class="mb-3">
            <label for="email" class="form-label">
              <i class="fas fa-envelope"></i> Correo
            </label>
            <input 
              type="email" 
              id="email" 
              name="email" 
              class="form-control"
              placeholder="correo@ejemplo.com"
              required
            >
          </div>

          <!-- Campo: Contraseña -->
          <div class="mb-3">
            <label for="password" class="form-label">
              <i class="fas fa-lock"></i> Contraseña
            </label>
            <input 
              type="text" 
              id="password" 
              name="password" 
              class="form-control"
              placeholder="Clave para el buzón"
              required
            >
          </div>

        <!-- Campo: Plataforma (Listado Desplegable) -->
        <div class="mb-3">
          <label for="plataforma" class="form-label">
            <i class="fas fa-tv"></i> Plataforma
          </label>
          <select 
            id="plataforma" 
            name="plataforma" 
            class="form-select"
            required
          >
            <option value="" disabled <?= empty($correo['plataforma']) ? 'selected' : '' ?>>Seleccione una plataforma</option>
            <?php foreach ($plataformasDisponibles as $plat): ?>
              <option value="<?= htmlspecialchars($plat) ?>" <?= ($correo['plataforma'] === $plat) ? 'selected' : '' ?>>
                <?= htmlspecialchars($plat) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>


          <!-- Botón de envío -->
          <button type="submit" class="btn btn-primary w-100">
            <i class="fas fa-save"></i> Guardar
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS (CDN) -->
<script 
  src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
></script>
</body>
</html>
