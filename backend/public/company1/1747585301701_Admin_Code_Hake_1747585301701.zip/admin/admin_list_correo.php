<?php
session_start();

// Verificar que el usuario sea un administrador
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}
require_once 'config.php';
require_once 'conexion.php'; // Archivo con tu conexión PDO ($pdo)

// Generar un token CSRF único para la sesión
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Parámetros de filtrado y búsqueda
$plataforma = isset($_GET['plataforma']) ? trim($_GET['plataforma']) : '';
$search     = isset($_GET['search']) ? trim($_GET['search']) : '';

// Parámetros de paginación
$limit = 10; // Número de resultados por página
$page  = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Construir la cláusula WHERE
$whereClauses = [];
$params = [];

if ($plataforma !== '') {
    $whereClauses[] = 'plataforma = :plataforma';
    $params['plataforma'] = $plataforma;
}

if ($search !== '') {
    $whereClauses[] = '(email LIKE :search OR password LIKE :search)';
    $params['search'] = '%' . $search . '%';
}

$whereSQL = '';
if (count($whereClauses) > 0) {
    $whereSQL = 'WHERE ' . implode(' AND ', $whereClauses);
}

// Contar el número total de registros que coinciden
$countSQL = "SELECT COUNT(*) FROM usuarios_correos $whereSQL";
$countStmt = $pdo->prepare($countSQL);
$countStmt->execute($params);
$total = $countStmt->fetchColumn();
$totalPages = ceil($total / $limit);

// Obtener la lista de plataformas disponibles para el filtro

// Obtener la lista de correos con limit y offset
$dataSQL = "SELECT id, email, password, plataforma, created_at
            FROM usuarios_correos
            $whereSQL
            ORDER BY id DESC
            LIMIT :limit OFFSET :offset";
$dataStmt = $pdo->prepare($dataSQL);

// Bind de parámetros
foreach ($params as $key => &$val) {
    if ($key === 'limit' || $key === 'offset') continue;
    $dataStmt->bindParam(':' . $key, $val);
}
$dataStmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$dataStmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

$dataStmt->execute();
$lista = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - Lista de Correos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS (CDN) -->
    <link 
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    >
    <!-- Font Awesome (CDN) -->
    <link 
        rel="stylesheet"
        href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    >
<link rel="stylesheet" href="styles/listcorreos.css">

</head>
<body>

<!-- Barra de navegación -->
<?php include 'navbar.php'; ?>

<!-- Contenedor principal -->
<div class="container">
    <div class="card p-3 bg-dark border-0 shadow">
        <div class="card-body">
            <h1 class="card-title mb-4 text-white">
                <i class="fas fa-list"></i> Lista de Correos
            </h1>

            <!-- Formulario de Filtro y Búsqueda -->
            <form method="GET" action="admin_list_correo.php" class="row g-3 mb-4">
                <!-- Seleccionar Todo Checkbox y Botón de Borrar Múltiple -->
                <div class="col-md-12 mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <input type="checkbox" id="select_all">
                        <label for="select_all" class="ms-2">Seleccionar Todo</label>
                    </div>
                    <button type="button" id="delete_selected" class="btn btn-danger">
                        <i class="fas fa-trash-alt"></i> Borrar Seleccionados
                    </button>
                </div>

                <!-- Filtro por Plataforma -->
                <div class="col-md-4">
                    <label for="plataforma" class="form-label"><i class="fas fa-tv"></i> Plataforma</label>
                    <select 
                        id="plataforma" 
                        name="plataforma" 
                        class="form-select"
                        >
                        <option value="">Todas las Plataformas</option>
                        <?php foreach ($plataformasDisponibles as $plat): ?>
                            <option value="<?= htmlspecialchars($plat) ?>" <?= ($plataforma === $plat) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($plat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Buscador -->
                <div class="col-md-6">
                    <label for="search" class="form-label"><i class="fas fa-search"></i> Buscar por Correo o Código</label>
                    <input 
                        type="text" 
                        id="search" 
                        name="search" 
                        class="form-control"
                        placeholder="Ingrese correo o código"
                        value="<?= htmlspecialchars($search) ?>"
                        >
                </div>

                <!-- Botón de Filtrar -->
                <div class="col-md-2 align-self-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filtrar
                    </button>
                </div>
            </form>
            <!-- Fin Formulario de Filtro y Búsqueda -->

            <!-- Tabla responsiva -->
            <form id="correo_form" method="POST" action="admin_delete_multiple.php">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="table-responsive">
                    <table class="table table-dark table-hover align-middle">
                        <thead>
                            <tr>
                                <th scope="col">Seleccionar</th>
                                <th>Correo</th>
                                <th>Código</th>
                                <th>Plataforma</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($lista): ?>
                                <?php foreach ($lista as $item): ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected_ids[]" value="<?= htmlspecialchars($item['id']) ?>">
                                        </td>
                                        <td><?= htmlspecialchars($item['email']) ?></td>
                                        <td><?= htmlspecialchars($item['password']) ?></td>
                                        <td><?= htmlspecialchars($item['plataforma'] ?? '') ?></td>
                                        <td>
                                            <a href="admin_edit_correo.php?id=<?= htmlspecialchars($item['id']) ?>" class="btn btn-sm btn-primary me-1">
                                                <i class="fas fa-edit"></i> 
                                            </a>
                                            <button type="button" class="btn btn-sm btn-danger delete-button" data-id="<?= htmlspecialchars($item['id']) ?>">
                                                <i class="fas fa-trash-alt"></i> 
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">
                                        No se encontraron registros.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </form>
            <!-- Fin tabla responsiva -->

            <!-- Paginación -->
            <?php if ($totalPages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <!-- Página Anterior -->
                        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" aria-label="Anterior">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>

                        <!-- Páginas -->
                        <?php
                        // Lógica para mostrar un rango de páginas
                        $adjacents = 2; // Número de páginas adyacentes a la actual

                        $start = ($page - $adjacents) > 1 ? $page - $adjacents : 1;
                        $end = ($page + $adjacents) < $totalPages ? $page + $adjacents : $totalPages;

                        if ($start > 1) {
                            echo '<li class="page-item"><a class="page-link" href="?'. http_build_query(array_merge($_GET, ['page' => 1])) .'">1</a></li>';
                            if ($start > 2) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                        }

                        for ($i = $start; $i <= $end; $i++) {
                            echo '<li class="page-item '. ($i == $page ? 'active' : '') .'"><a class="page-link" href="?'. http_build_query(array_merge($_GET, ['page' => $i])) .'">'. $i .'</a></li>';
                        }

                        if ($end < $totalPages) {
                            if ($end < $totalPages -1) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                            echo '<li class="page-item"><a class="page-link" href="?'. http_build_query(array_merge($_GET, ['page' => $totalPages])) .'">'. $totalPages .'</a></li>';
                        }
                        ?>

                        <!-- Página Siguiente -->
                        <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" aria-label="Siguiente">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>
            <!-- Fin Paginación -->
        </div>
    </div>
</div>
<!-- Fin Contenedor principal -->

<!-- Modal de Confirmación para Borrar -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="delete_form" method="POST" action="admin_delete_correo.php">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <input type="hidden" name="id" id="delete_id" value="">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Eliminación</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                ¿Estás seguro de que deseas eliminar este registro?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-danger">Sí, Eliminar</button>
            </div>
        </div>
    </form>
  </div>
</div>

<!-- Bootstrap JS (CDN) -->
<script 
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
></script>

<!-- Script para manejar la selección y eliminación múltiple -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Manejar el botón "Seleccionar Todo"
        const selectAllCheckbox = document.getElementById('select_all');
        const checkboxes = document.querySelectorAll('input[name="selected_ids[]"]');
        selectAllCheckbox.addEventListener('change', function() {
            checkboxes.forEach(cb => cb.checked = selectAllCheckbox.checked);
        });

        // Manejar el botón "Borrar Seleccionados"
        const deleteSelectedButton = document.getElementById('delete_selected');
        const correoForm = document.getElementById('correo_form');

        deleteSelectedButton.addEventListener('click', function() {
            const selected = Array.from(checkboxes).filter(cb => cb.checked).map(cb => cb.value);
            if (selected.length === 0) {
                alert('Por favor, selecciona al menos un registro para eliminar.');
                return;
            }

            if (confirm('¿Estás seguro de que deseas eliminar los registros seleccionados?')) {
                // Crear un formulario dinámico para enviar los IDs seleccionados
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'admin_delete_multiple.php';

                // Agregar el token CSRF
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = 'csrf_token';
                csrfInput.value = '<?= $_SESSION['csrf_token'] ?>';
                form.appendChild(csrfInput);

                // Agregar los IDs seleccionados
                selected.forEach(id => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'selected_ids[]';
                    input.value = id;
                    form.appendChild(input);
                });

                document.body.appendChild(form);
                form.submit();
            }
        });

        // Manejar la eliminación individual
        const deleteButtons = document.querySelectorAll('.delete-button');
        const confirmDeleteModal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));

        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                document.getElementById('delete_id').value = id;
                confirmDeleteModal.show();
            });
        });
    });
</script>
</body>
</html>
