<?php
// admin/login_admin.php
session_start();
if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Bootstrap CSS -->
  <link 
    rel="stylesheet" 
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  />
  <!-- Font Awesome -->
  <link 
    rel="stylesheet"
    href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
  />
  <!-- Tu CSS personalizado -->

  <link 
    rel="stylesheet" 
    href="styles/login_admin.css"
  />
<link rel="shortcut icon" href="/admin/assets/favicon.ico" type="image/x-icon">

</head>
<body>

  <div class="card login-card parpadeo">
    <div class="card-body text-center">
      <!-- Logo principal -->
      <img 
        src="assets/logo.png" 
        alt="Logo Admin" 
        class="mb-3" 
        style="max-width: 120px; height: auto;"
      />
      <h2 class="card-title">
        <i class="fas fa-user-shield me-2"></i>Admin Login
      </h2>

      <?php if ($error_message): ?>
        <div class="alert alert-danger text-center small">
          <i class="fas fa-exclamation-triangle me-1"></i><?= $error_message ?>
        </div>
      <?php endif; ?>

      <form action="procesa_admin_login.php" method="POST" class="mt-3">
        <div class="mb-4">
          <label for="username" class="form-label text-light">
            <i class="fas fa-user me-1"></i>Usuario
          </label>
          <input 
            type="text" name="username" id="username" 
            class="form-control form-control-lg" 
            placeholder="Tu usuario" required autofocus
          >
        </div>
        <div class="mb-4">
          <label for="password" class="form-label text-light">
            <i class="fas fa-key me-1"></i>Contraseña
          </label>
          <input 
            type="password" name="password" id="password" 
            class="form-control form-control-lg" 
            placeholder="••••••••" required
          >
        </div>
        <button type="submit" class="btn btn-submit btn-lg w-100">
          <i class="fas fa-sign-in-alt me-2"></i>Ingresar
        </button>
      </form>

      <div class="text-center text-light small mt-3">
        <a href="forgot_password.php">¿Olvidaste tu contraseña?</a>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
