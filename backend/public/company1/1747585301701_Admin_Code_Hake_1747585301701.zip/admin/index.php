<?php
// index.php

// Iniciar la sesión si es necesario
session_start();

// Redirigir a admin_form.php
header('Location: login_admin.php');
exit();
?>
